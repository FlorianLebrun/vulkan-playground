# Voxelize .obj and export it as also in .obj

## Third party library

This example uses https://github.com/karimnaaji/voxelizer, which is licensed under MIT Liense.
